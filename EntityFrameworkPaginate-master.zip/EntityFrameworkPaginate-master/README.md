# EntityFrameworkPaginate
One stop solution for entity framework pagination, sorting and filtering.

# Download and install
https://www.nuget.org/packages/EntityFrameworkPaginate/

# Tutorial
http://harshw.com/implementing-dynamic-filtering-sorting-pagination-entity-framework/
